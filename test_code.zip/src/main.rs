use a2f::{A2FConfig, A2FSender, A2FReceiver, current_timestamp, Packet};
use rand::seq::SliceRandom;
use rand::Rng; 
use std::net::UdpSocket;
use std::thread;
use std::time::Duration;
use std::sync::{Arc, Mutex};

fn main() -> anyhow::Result<()> {
    let args: Vec<String> = std::env::args().collect();
    
    if args.len() < 2 {
        println!("使い方:");
        println!("  cargo run -- --server [ポート番号]");
        println!("  cargo run -- --client <サーバーIP> <ポート番号>");
        println!();
        println!("例:");
        println!("  cargo run -- --server 8888");
        println!("  cargo run -- --client 127.0.0.1 8888");
        return Ok(());
    }
    
    match args[1].as_str() {
        "--server" => {
            let port = args.get(2).map(|p| p.parse::<u16>().unwrap()).unwrap_or(8888);
            server_mode(port)?;
        }
        "--client" => {
            if args.len() < 4 {
                println!("エラー: --client <サーバーIP> <ポート番号>");
                return Ok(());
            }
            let server_ip = args[2].clone();
            let port = args[3].parse::<u16>()?;
            client_mode(&server_ip, port)?;
        }
        _ => {
            println!("不明なオプション: {}", args[1]);
        }
    }
    
    Ok(())
}

fn server_mode(port: u16) -> anyhow::Result<()> {
    println!("=== A2F サーバーモード ===");
    println!("ポート {} で待受中...", port);
    
    let master_key = [0x42; 32];
    let config = A2FConfig::default();
    let mut receiver = A2FReceiver::new(master_key, &config);
    
    let socket = UdpSocket::bind(format!("0.0.0.0:{}", port))?;
    println!("バインド成功");
    
    let mut buf = [0u8; 65536];
    let mut rng = rand::thread_rng();
    
    loop {
        match socket.recv_from(&mut buf) {
            Ok((len, addr)) => {
                if let Ok(packet) = Packet::deserialize(&buf[..len]) {
                    println!(" 受信: from={}, timestamp={}, type={:?}", 
                             addr, packet.timestamp, packet.payload_type);
                    
                    match receiver.receive_packet(packet) {
                        Ok(Some(decrypted)) => {
                            let msg = String::from_utf8_lossy(&decrypted);
                            println!("   復号成功: {}", msg);
                        }
                        Ok(None) => {
                            println!("   バッファリング中");
                        }
                        Err(e) => {
                            println!("   エラー: {}", e);
                        }
                    }
                    
                    // ランダムにダミーパケットを返送（オプション）
                    if rng.gen_bool(0.1) {
                        let dummy_ts = current_timestamp();
                        let dummy_packet = {
                            let mut sender = A2FSender::new(master_key, &config);
                            sender.generate_dummy_packet(dummy_ts)
                        };
                        let data = dummy_packet.serialize()?;
                        socket.send_to(&data, addr)?;
                        println!("   🎭 ダミーパケットを返送");
                    }
                }
            }
            Err(e) => {
                eprintln!("受信エラー: {}", e);
            }
        }
    }
}

fn client_mode(server_ip: &str, port: u16) -> anyhow::Result<()> {
    println!("=== A2F クライアントモード ===");
    println!("サーバー {}:{} に接続", server_ip, port);
    
    let master_key = [0x42; 32];
    let config = A2FConfig::default();
    let mut sender = A2FSender::new(master_key, &config);
    let mut receiver = A2FReceiver::new(master_key, &config);
    
    let socket = UdpSocket::bind("0.0.0.0:0")?;
    socket.set_nonblocking(true)?;
    let server_addr = format!("{}:{}", server_ip, port);
    
    println!("ソケット準備完了");
    println!();
    
    // 受信用スレッド
    let receiver_arc = Arc::new(Mutex::new(receiver));
    let receiver_clone = receiver_arc.clone();
    let socket_clone = socket.try_clone()?;
    
    thread::spawn(move || {
        let mut buf = [0u8; 65536];
        loop {
            match socket_clone.recv_from(&mut buf) {
                Ok((len, addr)) => {
                    if let Ok(packet) = Packet::deserialize(&buf[..len]) {
                        let mut recv = receiver_clone.lock().unwrap();
                        match recv.receive_packet(packet) {
                            Ok(Some(decrypted)) => {
                                let msg = String::from_utf8_lossy(&decrypted);
                                println!("\nサーバーからの応答: {}", msg);
                            }
                            Ok(None) => {}
                            Err(e) => {
                                eprintln!("復号エラー: {}", e);
                            }
                        }
                    }
                }
                Err(ref e) if e.kind() == std::io::ErrorKind::WouldBlock => {
                    thread::sleep(Duration::from_millis(10));
                }
                Err(e) => {
                    eprintln!("受信エラー: {}", e);
                }
            }
        }
    });
    
    // メッセージを送信（修正: 異なる長さのメッセージをバイト配列として直接指定）
    let messages: Vec<&[u8]> = vec![
        b"Hello from A2F client!",
        b"This is a test message with timestamp bonding",
        b"High latency? No problem!",
        b"A2F protocol works even with packet loss",
        b"Ready for Starlink!",
    ];
    
    let mut rng = rand::thread_rng();
    
    for (i, msg) in messages.iter().enumerate() {
        let ts = current_timestamp() + i as u64;
        
        // 鍵とデータを生成
        let key_packet = sender.generate_key_packet(ts)?;
        let data_packet = sender.encrypt_data(msg, ts)?;
        
        // シャッフルして送信
        let mut packets = vec![key_packet, data_packet];
        packets.shuffle(&mut rng);
        
        for packet in packets {
            let data = packet.serialize()?;
            socket.send_to(&data, &server_addr)?;
            println!("送信: type={:?}, timestamp={}", packet.payload_type, packet.timestamp);
            
            // ランダムな遅延を入れて順序をバラバラに
            let delay = rng.gen_range(10..100);
            thread::sleep(Duration::from_millis(delay));
        }
        
        println!("   メッセージ{}送信完了: {:?}", i + 1, std::str::from_utf8(msg)?);
        println!();
        
        // メッセージ間の間隔
        thread::sleep(Duration::from_millis(500));
    }
    
    println!("すべてのメッセージを送信しました。");
    println!("5秒後に終了します...");
    thread::sleep(Duration::from_secs(5));
    
    Ok(())
}